var searchData=
[
  ['updateslidercolour_0',['updateSliderColour',['../class_circular_audio_buffer_audio_processor_editor.html#afe37bb4700509e784937f7dcfd2611a6',1,'CircularAudioBufferAudioProcessorEditor']]]
];
