var searchData=
[
  ['setfiltertype_0',['setFilterType',['../class_circular_audio_buffer_audio_processor.html#a6d948fe09ea1e5f1cca017dea1447de3',1,'CircularAudioBufferAudioProcessor']]],
  ['setsynctime_1',['setSyncTime',['../class_circular_audio_buffer_audio_processor.html#a94dc4884dbc48ea06a21690a3388eab6',1,'CircularAudioBufferAudioProcessor']]]
];
