var indexSectionsWithContent =
{
  0: "abcdfgkoprstu",
  1: "cfo",
  2: "bcdfgprsu",
  3: "akt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

