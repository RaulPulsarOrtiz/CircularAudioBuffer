var searchData=
[
  ['apvts_0',['apvts',['../class_circular_audio_buffer_audio_processor.html#af3ebc2cfa4896d98a6539114f2643e31',1,'CircularAudioBufferAudioProcessor']]]
];
